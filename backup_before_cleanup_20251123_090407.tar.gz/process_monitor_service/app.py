"""
Process Monitoring Service - Flask REST API

Provides RESTful endpoints for process monitoring, system metrics,
and process termination with risk assessment.

Endpoints:
    GET  /processes      - List all processes with risk scores
    GET  /metrics        - Get last 60s of system metrics
    POST /kill/<pid>     - Terminate a process

Author: Process Monitor Service
Version: 1.0.0
"""

import logging
import signal
import sys
from flask import Flask, jsonify, request
from flask_cors import CORS
import psutil

from services.process_service import ProcessService, MetricsCollector
from utils.metrics_buffer import MetricsBuffer


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend integration

# Initialize services
metrics_buffer = MetricsBuffer(max_size=60)
process_service = ProcessService()
metrics_collector = MetricsCollector(metrics_buffer, interval=1.0)


# ============================================================================
# API Endpoints
# ============================================================================

@app.route('/processes', methods=['GET'])
def get_processes():
    """
    GET /processes
    
    Retrieve all running processes with risk assessment.
    
    Returns:
        JSON response with:
            - processes: Array of process objects
            - summary: System summary statistics
    
    Example Response:
        {
            "processes": [
                {
                    "pid": 1234,
                    "name": "chrome",
                    "cpu_usage": 12.5,
                    "memory_usage": 245.67,
                    "path": "/usr/bin/chrome",
                    "username": "user",
                    "risk_score": 25,
                    "risk_level": "Low",
                    "risk_factors": []
                }
            ],
            "summary": {
                "total": 120,
                "high_risk": 3,
                "cpu_percent": 45.2,
                "memory_percent": 62.1
            }
        }
    """
    try:
        logger.debug("Fetching all processes")
        result = process_service.get_all_processes()
        return jsonify(result), 200
    
    except Exception as e:
        logger.error(f"Error fetching processes: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@app.route('/metrics', methods=['GET'])
def get_metrics():
    """
    GET /metrics
    
    Retrieve system metrics for the last 60 seconds.
    
    Returns:
        JSON response with CPU and memory usage arrays.
    
    Example Response:
        {
            "cpu": [
                {"time": "2025-11-23T08:30:01Z", "usage": 45.2},
                {"time": "2025-11-23T08:30:02Z", "usage": 46.1}
            ],
            "memory": [
                {"time": "2025-11-23T08:30:01Z", "usage": 62.1},
                {"time": "2025-11-23T08:30:02Z", "usage": 62.3}
            ]
        }
    """
    try:
        logger.debug("Fetching system metrics")
        metrics = metrics_buffer.get_all_metrics()
        return jsonify(metrics), 200
    
    except Exception as e:
        logger.error(f"Error fetching metrics: {e}")
        return jsonify({
            'error': 'Internal server error',
            'message': str(e)
        }), 500


@app.route('/kill/<int:pid>', methods=['POST'])
def kill_process(pid):
    """
    POST /kill/<pid>
    
    Terminate a process by PID.
    
    Args:
        pid: Process ID (integer)
    
    Returns:
        JSON response with status and message.
    
    Example Success Response (200):
        {
            "status": "success",
            "message": "Process 1234 (chrome) terminated successfully",
            "pid": 1234
        }
    
    Example Error Response (404):
        {
            "status": "error",
            "message": "Process not found",
            "pid": 9999
        }
    
    Example Error Response (403):
        {
            "status": "error",
            "message": "Access denied",
            "pid": 1
        }
    """
    try:
        logger.info(f"Attempting to kill process {pid}")
        result = process_service.kill_process(pid)
        return jsonify(result), 200
    
    except psutil.NoSuchProcess:
        logger.warning(f"Process {pid} not found")
        return jsonify({
            'status': 'error',
            'message': 'Process not found',
            'pid': pid
        }), 404
    
    except psutil.AccessDenied:
        logger.warning(f"Access denied to kill process {pid}")
        return jsonify({
            'status': 'error',
            'message': 'Access denied - insufficient permissions',
            'pid': pid
        }), 403
    
    except psutil.TimeoutExpired:
        logger.error(f"Timeout killing process {pid}")
        return jsonify({
            'status': 'error',
            'message': 'Process termination timed out',
            'pid': pid
        }), 500
    
    except Exception as e:
        logger.error(f"Error killing process {pid}: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e),
            'pid': pid
        }), 500


@app.route('/health', methods=['GET'])
def health_check():
    """
    GET /health
    
    Health check endpoint for service monitoring.
    
    Returns:
        JSON with service status.
    """
    return jsonify({
        'status': 'healthy',
        'service': 'process_monitor_service',
        'metrics_collector_running': metrics_collector.is_running(),
        'metrics_buffer_size': metrics_buffer.get_size()
    }), 200


# ============================================================================
# Error Handlers
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({
        'error': 'Not found',
        'message': 'The requested endpoint does not exist'
    }), 404


@app.errorhandler(405)
def method_not_allowed(error):
    """Handle 405 errors."""
    return jsonify({
        'error': 'Method not allowed',
        'message': 'The HTTP method is not supported for this endpoint'
    }), 405


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    logger.error(f"Internal server error: {error}")
    return jsonify({
        'error': 'Internal server error',
        'message': 'An unexpected error occurred'
    }), 500


# ============================================================================
# Application Lifecycle
# ============================================================================

def shutdown_handler(signum, frame):
    """
    Graceful shutdown handler.
    
    Called when receiving SIGINT or SIGTERM signals.
    Stops the metrics collector and exits cleanly.
    """
    logger.info("Received shutdown signal, stopping metrics collector...")
    metrics_collector.stop()
    logger.info("Shutdown complete")
    sys.exit(0)


def startup():
    """Initialize and start background services."""
    logger.info("Starting metrics collection thread...")
    metrics_collector.start()
    
    # Register shutdown handlers
    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == '__main__':
    # Start background services
    startup()
    
    # Start Flask server
    logger.info("=" * 60)
    logger.info("Process Monitoring Service")
    logger.info("=" * 60)
    logger.info("Endpoints:")
    logger.info("  GET  /processes  - List all processes")
    logger.info("  GET  /metrics    - Get system metrics (last 60s)")
    logger.info("  POST /kill/<pid> - Terminate a process")
    logger.info("  GET  /health     - Health check")
    logger.info("=" * 60)
    
    # Run Flask app
    app.run(
        host='0.0.0.0',
        port=5001,
        debug=False,  # Disable debug mode in production
        use_reloader=False  # Disable reloader to prevent duplicate threads
    )
