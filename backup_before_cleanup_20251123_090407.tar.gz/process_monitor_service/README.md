# Process Monitor Service

A Python Flask microservice for real-time process monitoring, risk assessment, and system metrics collection.

## Features

- 🔍 **Process Enumeration** - List all running processes with detailed information
- ⚠️ **Risk Assessment** - Multi-factor risk scoring (CPU, memory, path, name, user)
- 📊 **System Metrics** - Real-time CPU and memory tracking (last 60 seconds)
- 🔪 **Process Termination** - Safely kill processes with proper error handling
- 🧵 **Background Monitoring** - Metrics collection via daemon thread (1s interval)
- 🌐 **REST API** - Clean JSON endpoints with CORS support

## Architecture

```
process_monitor_service/
├── app.py                      # Flask REST API
├── services/
│   ├── __init__.py
│   └── process_service.py     # ProcessService & MetricsCollector
├── utils/
│   ├── __init__.py
│   ├── metrics_buffer.py      # Thread-safe circular buffer
│   └── risk_engine.py         # Risk scoring engine
└── requirements.txt           # Dependencies
```

## Installation

```bash
cd process_monitor_service

# Create virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Start the Service

```bash
python app.py
```

The service will start on `http://0.0.0.0:5001`

### API Endpoints

#### 1. **GET /processes**

List all running processes with risk scores.

```bash
curl http://localhost:5001/processes | jq
```

**Response:**
```json
{
  "processes": [
    {
      "pid": 1234,
      "name": "chrome",
      "cpu_usage": 12.5,
      "memory_usage": 245.67,
      "path": "/usr/bin/chrome",
      "username": "user",
      "risk_score": 25,
      "risk_level": "Low",
      "risk_factors": []
    }
  ],
  "summary": {
    "total": 120,
    "high_risk": 3,
    "cpu_percent": 45.2,
    "memory_percent": 62.1
  }
}
```

#### 2. **GET /metrics**

Get system metrics for the last 60 seconds.

```bash
curl http://localhost:5001/metrics | jq
```

**Response:**
```json
{
  "cpu": [
    {"time": "2025-11-23T08:30:01Z", "usage": 45.2},
    {"time": "2025-11-23T08:30:02Z", "usage": 46.1}
  ],
  "memory": [
    {"time": "2025-11-23T08:30:01Z", "usage": 62.1},
    {"time": "2025-11-23T08:30:02Z", "usage": 62.3}
  ]
}
```

#### 3. **POST /kill/<pid>**

Terminate a process by PID.

```bash
curl -X POST http://localhost:5001/kill/1234 | jq
```

**Success Response (200):**
```json
{
  "status": "success",
  "message": "Process 1234 (chrome) terminated successfully",
  "pid": 1234
}
```

**Error Responses:**
- `404` - Process not found
- `403` - Access denied
- `500` - Termination timeout or internal error

#### 4. **GET /health**

Health check endpoint.

```bash
curl http://localhost:5001/health | jq
```

**Response:**
```json
{
  "status": "healthy",
  "service": "process_monitor_service",
  "metrics_collector_running": true,
  "metrics_buffer_size": 60
}
```

## Risk Scoring

Processes are scored 0-100 based on multiple factors:

| Factor | Points | Condition |
|--------|--------|-----------|
| High CPU | +30 | CPU usage > 50% |
| Elevated CPU | +15 | CPU usage > 25% |
| High Memory | +20 | Memory > 500 MB |
| Elevated Memory | +10 | Memory > 250 MB |
| Suspicious Path | +40 | Temp/Downloads directories |
| Suspicious Name | +30 | powershell, cmd, rundll32, etc. |
| Different User | +20 | Running as non-current user |

**Risk Levels:**
- **Low**: 0-30 points
- **Medium**: 31-60 points
- **High**: 61-100 points

## Integration with Frontend

Update the frontend API base URL to point to this service:

```typescript
// In src/api/apiClient.ts
const API_BASE_URL = 'http://localhost:5001';
```

The service has CORS enabled for seamless frontend integration.

## Testing

### Manual Testing

```bash
# Test process listing
curl http://localhost:5001/processes

# Test metrics (wait 10s after startup for data)
sleep 10
curl http://localhost:5001/metrics

# Test process kill (safe test)
sleep 300 &  # Start background sleep
PID=$!
curl -X POST http://localhost:5001/kill/$PID

# Test health check
curl http://localhost:5001/health
```

### Expected Behavior

1. **Metrics Collection** - Starts immediately, samples every 1 second
2. **Buffer Size** - Grows to 60 entries max, then maintains circular buffer
3. **Risk Assessment** - All processes automatically scored on every request
4. **Graceful Termination** - Tries `terminate()` first, then `kill()` if needed

## Logging

All operations are logged with timestamps:

```
[2025-11-23 08:30:01] [INFO] Starting metrics collection thread...
[2025-11-23 08:30:01] [INFO] Metrics collector started
[2025-11-23 08:30:01] [INFO] Process Monitoring Service
[2025-11-23 08:30:15] [INFO] Attempting to kill process 1234
[2025-11-23 08:30:15] [INFO] Successfully terminated process 1234 (chrome)
```

## Error Handling

The service handles common psutil exceptions:

- `NoSuchProcess` - Process disappeared
- `AccessDenied` - Insufficient permissions
- `ZombieProcess` - Process in zombie state
- `TimeoutExpired` - Termination timeout

## Graceful Shutdown

Press `Ctrl+C` to stop the service gracefully:

```
^C[2025-11-23 08:35:00] [INFO] Received shutdown signal, stopping metrics collector...
[2025-11-23 08:35:00] [INFO] Metrics collector stopped
[2025-11-23 08:35:00] [INFO] Shutdown complete
```

## Production Deployment

For production, consider:

1. **Use a production WSGI server** (Gunicorn, uWSGI)
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5001 app:app
   ```

2. **Enable authentication** - Add API keys or OAuth
3. **Configure HTTPS** - Use reverse proxy (nginx, Apache)
4. **Add rate limiting** - Prevent abuse
5. **Monitor logs** - Use log aggregation (ELK, Splunk)
6. **Set resource limits** - Prevent resource exhaustion

## Troubleshooting

### Permission Errors

If you get "Access denied" errors when killing processes:

- Make sure you're not trying to kill system processes (PID 1)
- Run with appropriate permissions (may need sudo for some processes)

### No Metrics Data

If `/metrics` returns empty arrays:

- Wait at least 1 second after startup
- Check logs for errors in metrics collection thread
- Verify background thread is running via `/health`

### High CPU Usage

If the service uses too much CPU:

- Increase metrics collection interval (currently 1s)
- Reduce process enumeration frequency

## License

Same as parent project (threat-sentinel-view)

## Author

Process Monitor Service - Part of Threat Sentinel View
